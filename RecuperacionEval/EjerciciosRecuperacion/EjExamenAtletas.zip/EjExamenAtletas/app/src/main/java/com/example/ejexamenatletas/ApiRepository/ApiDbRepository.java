package com.example.ejexamenatletas.ApiRepository;

public class ApiDbRepository {
    //Private Attributes

    //Constructor

    //Methods
}
