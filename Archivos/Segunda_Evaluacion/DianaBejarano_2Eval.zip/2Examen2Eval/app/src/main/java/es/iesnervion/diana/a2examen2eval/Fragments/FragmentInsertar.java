package es.iesnervion.diana.a2examen2eval.Fragments;

import androidx.fragment.app.Fragment;

public class FragmentInsertar extends Fragment {
}
